document.addEventListener('DOMContentLoaded', () => {
    const mic = document.getElementById('mic');
    const popup = document.getElementById('popup');
    const inputText = document.getElementById('inputText');
    const outputText1 = document.getElementById('outputText1');
    const outputText2 = document.getElementById('outputText2');
    const sourceLanguageDropdown = document.getElementById('sourceLanguage');
    const targetLanguageDropdown1 = document.getElementById('targetLanguage1');
    const targetLanguageDropdown2 = document.getElementById('targetLanguage2');
    const translateButton1 = document.getElementById('translateButton1');
    const translateButton2 = document.getElementById('translateButton2');
    const speaker1 = document.getElementById('speaker1');
    const speaker2 = document.getElementById('speaker2');
    const stopButton = document.getElementById('stop');
    const copyIcons = document.querySelectorAll('.copy-icon');
    const loadingModal = document.getElementById('loadingModal');
    let recognition;
    let audio; 

    const showLoading = () => {
        loadingModal.style.display = 'flex';
    };

    const hideLoading = () => {
        loadingModal.style.display = 'none';
    };

    mic.addEventListener('click', () => {
        popup.classList.remove('hidden');
        navigator.mediaDevices.getUserMedia({ audio: true })
            .then(stream => {
                recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
                recognition.lang = sourceLanguageDropdown.value;
                recognition.start();
                recognition.onresult = (event) => {
                    const transcript = event.results[0][0].transcript;
                    inputText.value = transcript;
                };
                recognition.onend = () => {
                    popup.classList.add('hidden');
                };
                setTimeout(() => {
                    recognition.stop();
                }, 120000); 
            })
            .catch(err => {
                console.error('Error accessing microphone: ', err);
                popup.classList.add('hidden');
            });
    });

    translateButton1.addEventListener('click', () => {
        const sourceLanguage = sourceLanguageDropdown.value;
        const targetLanguage = targetLanguageDropdown1.value;
        const text = inputText.value;

        showLoading(); 
        fetch('/translate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ text, source_language: sourceLanguage, target_language: targetLanguage })
        })
        .then(response => response.json())
        .then(data => {
            outputText1.innerHTML = `<p class="text-gray-700">${data.translated_text}</p>`;
        })
        .catch(err => console.error('Error translating text: ', err))
        .finally(() => hideLoading()); 
    });

    translateButton2.addEventListener('click', () => {
        const sourceLanguage = sourceLanguageDropdown.value;
        const targetLanguage = targetLanguageDropdown2.value;
        const text = inputText.value;

        showLoading(); 
        fetch('/translate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ text, source_language: sourceLanguage, target_language: targetLanguage })
        })
        .then(response => response.json())
        .then(data => {
            outputText2.innerHTML = `<p class="text-gray-700">${data.translated_text}</p>`;
        })
        .catch(err => console.error('Error translating text: ', err))
        .finally(() => hideLoading()); 
    });

    speaker1.addEventListener('click', () => {
        let translatedText = outputText1.innerText;
        let targetLanguage = targetLanguageDropdown1.value;

        showLoading(); 
        fetch('/speak', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ text: translatedText, language_code: targetLanguage }),
        })
        .then(response => response.blob())
        .then(blob => {
            const audioUrl = URL.createObjectURL(blob);
            audio = new Audio(audioUrl); 
            audio.play();
        })
        .catch(err => console.error('Error speaking text: ', err))
        .finally(() => hideLoading()); 
    });

    speaker2.addEventListener('click', () => {
        let translatedText = outputText2.innerText;
        let targetLanguage = targetLanguageDropdown2.value;

        showLoading(); 
        fetch('/speak', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ text: translatedText, language_code: targetLanguage }),
        })
        .then(response => response.blob())
        .then(blob => {
            const audioUrl = URL.createObjectURL(blob);
            audio = new Audio(audioUrl); 
            audio.play();
        })
        .catch(err => console.error('Error speaking text: ', err))
        .finally(() => hideLoading()); 
    });

    stopButton.addEventListener('click', () => {
        if (audio) {
            audio.pause();  
            audio.currentTime = 0;  
        }
    });

    copyIcons.forEach(icon => {
        icon.addEventListener('click', () => {
            const targetId = icon.getAttribute('data-target');
            const targetElement = document.getElementById(targetId);
            const textToCopy = targetElement.value || targetElement.innerText;

            navigator.clipboard.writeText(textToCopy)
                .then(() => {
                    console.log('Text copied to clipboard');
                })
                .catch(err => {
                    console.error('Error copying text: ', err);
                });
        });
    });
});
