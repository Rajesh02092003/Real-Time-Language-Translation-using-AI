from flask import Flask, request, render_template, jsonify, send_file
import speech_recognition as sr
from googletrans import Translator
from langdetect import detect
from gtts import gTTS
import os

app = Flask(__name__)
translator = Translator()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/speech-to-text', methods=['POST'])
def speech_to_text():
    recognizer = sr.Recognizer()
    audio_file = request.files['audio']
    with sr.AudioFile(audio_file) as source:
        audio_data = recognizer.record(source)
        text = recognizer.recognize_google(audio_data)
    return jsonify({'text': text})

@app.route('/translate', methods=['POST'])
def translate():
    data = request.json
    text = data['text']
    source_language = data.get('source_language')
    target_language = data['target_language']
    translated = translator.translate(text, src=source_language, dest=target_language).text
    return jsonify({'translated_text': translated})

@app.route('/detect-language', methods=['POST'])
def detect_language():
    text = request.json['text']
    language = detect(text)
    return jsonify({'language': language})

@app.route('/speak', methods=['POST'])
def speak():
    data = request.json
    text = data['text']
    language_code = data['language_code']
    tts = gTTS(text=text, lang=language_code, slow=False)
    tts.save("output.mp3")
    return send_file("output.mp3", as_attachment=False, mimetype='audio/mpeg')

if __name__ == "__main__":
    app.run()